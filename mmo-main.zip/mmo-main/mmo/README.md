<div align="center">
  <h1>mmo-rs</h1>
  <p>
    <strong>Libraries to build scalable game servers</strong>
  </p>
  <p>

[![crates.io](https://img.shields.io/crates/v/mmo?label=latest)](https://crates.io/crates/mmo)
[![Documentation](https://docs.rs/mmo/badge.svg?version=0.0.2)](https://docs.rs/mmo/0.0.2)
![MIT or Apache 2.0 licensed](https://img.shields.io/crates/l/mmo.svg)
  </p>
</div>

---

See dwarfhack.com for mor info for now.